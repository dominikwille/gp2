tar cvf wsk2.tar *
scp ./wsk2.tar dominikwille@userpage.fu-berlin.de:public_html/
